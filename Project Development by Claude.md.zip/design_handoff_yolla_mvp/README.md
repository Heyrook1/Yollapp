# Handoff: Yolla MVP Ekranları (1–9) + v2 Geliştirmeleri

## Overview
Yolla (KKTC içi gig-economy kargo platformu) için Claude.md'deki MVP sırasını (§11, adım 1–9) kapsayan hi-fi ekran tasarımları + rakip analizine dayalı v2 geliştirme önerileri. Hedef codebase: `Yolla/` monorepo — Next.js App Router + Tailwind CSS + Prisma/Supabase (`apps/web`).

## About the Design Files
Bu paketteki `.dc.html` dosyaları **HTML olarak hazırlanmış tasarım referanslarıdır** — doğrudan kopyalanacak production kodu değildir. Görev: bu tasarımları mevcut codebase ortamında (**Next.js + React + Tailwind**, mevcut `components/ui/` ve `features/*/components/` pattern'leri ile) yeniden inşa etmek. Dosyalar tarayıcıda açılarak birebir referans alınabilir; içlerindeki inline stiller Tailwind theme token'larına eşlenir (aşağıda tablo).

## Fidelity
**High-fidelity (hifi).** Renkler, tipografi, boşluklar ve durumlar (boş/hata/yükleme/yetkisiz) finaldir. `globals.css` @theme token'ları esas alınmıştır; piksel-piksel yeniden üretin.

## Design Tokens → Tailwind eşlemesi
Hepsi zaten `apps/web/src/app/globals.css` içinde tanımlı:

| Tasarımdaki değer | Token / Tailwind |
|---|---|
| `#2f6bff` | `yolla-blue` (primary CTA, aktif tab, linkler) |
| `#1f54d6` | `yolla-blue-dark` (hover) |
| `#e8efff` | `yolla-blue-soft` (seçili kart bg, mavi pill bg) |
| `#ff6a00` / `#fff0e6` | `yolla-orange` / `yolla-orange-soft` (Ekspres, esnaf, bonus) |
| `#0b1220` | `ink` = `surface-dark` (metin; dark kartlar: cüzdan, takip linki, admin sidebar) |
| `#5b657a` | `ink-secondary` |
| `#f5f7fb` | `surface` (sayfa bg) |
| `#ffffff` | `surface-elevated` (kart bg) |
| `#e2e6ef` | `border` |
| `#0f9f6e` / `#e5a100` / `#e11d48` | `success` / `warning` / `danger` |
| 12px radius | `rounded-[12px]` = `--radius-control` |
| 16–24px radius | `--radius-sheet` (dark hero kartlar, telefon çerçevesi) |
| Font | `"Segoe UI", ui-sans-serif, system-ui` (mevcut `--font-sans`) |

Ek türetilmiş tonlar (pill'ler): yeşil pill `#e6f6ef`/`#0a7a54`, sarı pill `#fdf3d7`/`#8a6100`, kırmızı pill `#fde8ec`/`#a3123a`, turuncu pill `#fff0e6`/`#b34a00`. Bunları `globals.css`'e `--color-success-soft` vb. olarak ekleyin.

Genel kurallar: min dokunma hedefi 48px (`min-h-12`), buton `font-semibold text-base rounded-[12px]`, kart `bg-white border border-border rounded-[12px] p-4`, sayı kolonları `tabular-nums`, para formatı `1.250,00 ₺` (tr-TR), saat `14:00`.

## Screens / Views (dosya → route eşlemesi)

### 01 Public ve Auth.dc.html → MVP 1
- **Landing** `app/(public)/page.tsx` — mevcut; birebir korunur (dark `surface-dark`, marka görseli `public/brand/yolla-mark.png`, Başla/Giriş yap).
- **Login / Signup + hata & bilgi durumları** `AuthForm.tsx` — mevcut; focus state ekleyin: `border-[1.5px] border-yolla-blue` + 4px `yolla-blue-soft` halo (`shadow-[0_0_0_4px_#e8efff]`), hata alanında `border-danger`.

### 02 Sender.dc.html → MVP 2–3, 6
- **Sender home** `(sender)/sender/page.tsx` — başlık 30px/semibold, "SON GÖNDERİ" kartı ekleyin (`queryMyShipments` ilk kayıt).
- **Yeni gönderi — 3 adımlı stepper** `CreateShipmentForm.tsx`'in yerine geçer. Adımlar: (1) Rota & paket — bölge kartları (fiyatlı), boyut kartları S/M/L/XL (çarpanlı), adresler, alıcı; (2) Zaman — pencere kartları (Müsait/Dolu), Yolla Ekspres toggle kartı (turuncu, +%50); (3) Fiyat — breakdown kartı (taban ücret, çarpan, ekspres primi, toplam 28px/700) + snapshot notu. Seçili kart stili: `border-[1.5px] border-yolla-blue bg-yolla-blue-soft`. Alt sabit CTA bar. **Fiyat client'ta yalnız gösterim — hesap her zaman `pricing/service.ts`'te (Claude.md §5.4).** Aynı Zod şemaları, aynı server action; step state client-side.
- **Gönderilerim** `ShipmentList.tsx` — status pill'leri (renkler yukarıda), QUOTED kartında Öde butonu, Ekspres etiketi turuncu.
- **Gönderi detay + takip linki** YENİ route `(sender)/sender/shipments/[id]/page.tsx` — dark takip linki kartı (mono link, Kopyala + WhatsApp paylaş), dikey `ShipmentEvent` timeline (yeşil=geçmiş, mavi+halo=aktif), kurye kartı, kurallı iptal butonu (danger outline).
- **Boş / hata / yükleme / yetkisiz** — tasarımdaki 4 blok; skeleton kartlar `animate-pulse`.

### 03 Courier ve Wallet.dc.html → MVP 1, 4–5, 7
- **Başvuru** `ApplyForm.tsx` — araç tipi kart seçici, bölge chip'leri (pill), belge yükleme (Supabase Storage signed URL, `lib/storage.ts`), 3 vetting durumu.
- **Açık işler** `AvailableJobsList.tsx` — filtre chip satırı, kartta **komisyon sonrası kazanç** göster (`tutar × (1 − commissionBps/10000)`), Ekspres kart `border-yolla-orange`.
- **Aktif iş — durum akışı** `MyJobsList.tsx` genişletmesi — ilerleme barı + tek ana CTA (Paketi aldım → Yola çıktım → Teslim ettim) + "Teslim edilemedi" (danger outline). **Her buton `transition(shipment, event)` çağırır (`packages/core/shipment-state.ts`), status'u doğrudan update etmek yasak; her geçiş `ShipmentEvent`'e loglanır** — ekrandaki event log listesi bu tablodan.
- **Cüzdan** YENİ `features/wallet/` — dark bakiye kartı (bakiye = `SUM(LedgerEntry)`), turuncu "Anında ödeme 3/5" progress kartı, ledger listesi (+yeşil / −ink).
- **Para çekimi** — tutar + "Tümü", IBAN (mono), idempotency-key'li payout action, çekim geçmişi pill'leri (Ödendi/Bekliyor).

### 04 Takip Linki.dc.html → MVP 6, 8
- YENİ route `app/(public)/t/[token]/page.tsx` — auth'suz, rate-limit'li. Harita **adaptör arkasında** (`lib/map/` interface; SDK'yı doğrudan import etme). Üstte 280px harita (kurye konumu pulse animasyonlu, rota noktalı çizgi), ETA kartı, 3 adımlı durum listesi, **maskelenmiş adres** ("Karakum Sitesi ••••"), telefon asla render edilmez.
- **Teslim + rating** — yeşil başarı kartı, 5 yıldız (34px, seçili `#ff6a00`, boş `#d7dde8`), yorum, gönderi başına 1 Rating.
- **Geçersiz link / teslim başarısız / yükleme** durumları.

### 05 Admin.dc.html → MVP 1, 9
- YENİ layout: 220px dark sidebar (`surface-dark`, aktif item `bg-yolla-blue`, Kuryeler badge'i turuncu) + beyaz top bar (arama). Mevcut `(admin)/layout.tsx` değişir.
- **Operasyon** — 4 stat kartı (Bugün gönderi / Aktif kurye / Komisyon / Açık sorun-turuncu), gönderi tablosu (grid kolonlar: KOD mono, ROTA, KURYE, DURUM pill, TUTAR sağa hizalı `tabular-nums`) + sağda 60/40 detay paneli: `ShipmentEvent` audit log + aksiyonlar (kurallı iptal, takip linki iptali).
- **Kurye yönetimi** — `PendingList.tsx` yerine 3 kolonlu başvuru kartları (Onayla mavi / Reddet danger; red nedeni inputu) + onaylı kurye tablosu (puan, teslimat sayısı).

### 06 Gelistirmeler.dc.html → v2 (MVP sonrası backlog)
Sırayla: adres defteri + tekrar gönder → yolda pencere değiştirme + teslim tercihleri → toplu gönderi (esnaf; toplu indirim `PlatformConfig`'e) → bahşiş (komisyonsuz ayrı `LedgerEntry` tipi) → yoğun bölge sinyali + seri bonusu → maskeli mesajlaşma (numara sızdırmaz, §6.4). Her biri ayrı feature modülü + `docs/specs/` dosyası ister.

## Interactions & Behavior
- Buton hover: bir ton koyulaş (`hover:bg-yolla-blue-dark`); kart hover: border maviye döner.
- Stepper: adım başlıkları tıklanabilir; ileri CTA "Devam → Fiyatı gör → Oluştur ve öde".
- Ekspres toggle: track turuncuya kayar (150ms), pencere seçimi devre dışı görünür ("en kısa sürede").
- Kurye durum CTA'sı pending'de `opacity-60` + "…yor" metni (mevcut pattern).
- Takip haritasında kurye noktası: 2s pulse (`box-shadow` keyframe).
- Tüm listelerde: boş durum (marka görselli), hata (kırmızı banner, TR mesaj — ham hata sızdırma), yükleme (skeleton), yetkisiz (Giriş yap linki). Claude.md §10.4 zorunlu.

## State Management
- Stepper/toggle/yıldız: local client state (`useState`); Zustand gerekmiyor.
- Veri: Server Components + `queries.ts` (mevcut pattern). Mutasyonlar server action üçlüsüyle: `requireAuth → schema.parse → assertCanAccess`.
- Cüzdan bakiyesi türetilmiş değer — kolon değil (§5.2). Payout idempotent (§5.6).

## Assets
- `assets/yolla-mark.png` → codebase'de zaten `apps/web/public/brand/yolla-mark.png`.
- İkon seti yok — tasarımlar ikonsuz; eklenecekse tek set seçin (ör. Lucide 1.5px) ve tüm yüzeylerde aynı kalın.

## Files
- `01 Public ve Auth.dc.html` — landing, login/signup + durumlar
- `02 Sender.dc.html` — home, 3 adımlı yeni gönderi (etkileşimli), liste, detay+takip linki, durumlar
- `03 Courier ve Wallet.dc.html` — başvuru/vetting, açık işler, durum akışı (etkileşimli), cüzdan, para çekimi
- `04 Takip Linki.dc.html` — canlı takip, teslim+rating (etkileşimli), hata durumları
- `05 Admin.dc.html` — operasyon paneli (etkileşimli detay), kurye yönetimi
- `06 Gelistirmeler.dc.html` — v2 önerileri + rakip analizi
- `assets/yolla-mark.png`

Uygulama sırası Claude.md §11'i izler; her feature küçük PR + zorunlu testler (pricing, wallet ledger, shipment-state, sahiplik).
